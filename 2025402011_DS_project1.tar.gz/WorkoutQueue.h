#include "WorkoutQueueNode.h"

class WorkoutQueue {
private:
    WorkoutQueueNode* head;
    WorkoutQueueNode* rear;

    int size;
    int capacity;

public:
    // Constructor and destructor
    WorkoutQueue();
    ~WorkoutQueue();

    // Queue status and existing interface
    bool empty();
    bool full();
    bool exist();
    void push();

    // Data search and insertion
    bool contains(const SetData& d) const;
    bool add(const SetData& d);

    // Data access and removal
    WorkoutQueueNode* pop();
    WorkoutQueueNode* front();

    // Return the current number of elements
    int count() const {
        return size;
    }
};