#include "SetData.h"

#include <string>

class Routine;

class RoutineNode {
    friend class Routine;

private:
    // Exercise data
    std::string exercise;
    std::string equipment;
    std::string dtime;

    // Exercise duration and calories
    int seconds = 0;
    int kcal = 0;

    // Doubly linked list pointers
    RoutineNode* prev = nullptr;
    RoutineNode* next = nullptr;

public:
    // Default constructor
    RoutineNode() = default;

    // Construct a node from exercise data
    explicit RoutineNode(const SetData& d)
        : exercise(d.exercise),
          equipment(d.equipment),
          dtime(d.dtime),
          seconds(d.seconds),
          kcal(d.kcal) {}

    // Destructor
    ~RoutineNode() = default;

    // Existing interface
    void set() {}
};