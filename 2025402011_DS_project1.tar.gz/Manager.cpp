#include "Manager.h"

#include <iostream>
#include <sstream>
#include <algorithm>

using namespace std;


// Constructor and destructor
Manager::Manager() {}

Manager::~Manager() {
    if (fcmd.is_open()) {
        fcmd.close();
    }

    if (flog.is_open()) {
        flog.close();
    }
}


// Write an error log
void Manager::error(int c) {
    flog << "========ERROR========\n";
    flog << c << "\n";
    flog << "====================\n";
}


// Write a command result log
void Manager::block(
    const string& h,
    const string& body
) {
    flog << "========" << h << "========\n";
    flog << body;

    if (!body.empty() && body.back() != '\n') {
        flog << '\n';
    }

    flog << "====================\n";
}


// Select data matching the search criteria
vector<SetData> Manager::selectData(
    const string& kind,
    const string& arg,
    bool& ok
) const {
    ok = true;

    vector<SetData> v;

    if (kind == "EXERCISE") {
        v = exb.byExercise(arg);
    }
    else if (kind == "EQUIPMENT") {
        v = eqb.byEquipment(arg);
    }
    else if (kind == "SET") {
        SetData d;

        // First, attempt to parse the complete data format
        if (!parseSet(arg, d)) {
            // Also allow the exercise|equipment format for SET searches
            size_t p = arg.find('|');

            if (
                p == string::npos ||
                p == 0 ||
                p + 1 >= arg.size()
            ) {
                ok = false;
                return v;
            }

            d.exercise = arg.substr(0, p);
            d.equipment = arg.substr(p + 1);
        }

        // Select data matching both the exercise and equipment names
        for (const auto& x : exb.byExercise(d.exercise)) {
            if (x.equipment == d.equipment) {
                v.push_back(x);
            }
        }
    }
    else {
        ok = false;
    }

    return v;
}


// Execute the command file
void Manager::run(const char* command) {
    flog.open("log.txt", ios::app);
    fcmd.open(command);

    if (!flog || !fcmd) {
        return;
    }

    string line;

    while (getline(fcmd, line)) {
        if (line.empty()) {
            continue;
        }

        // Separate the command from its arguments
        size_t p = line.find(' ');

        string cmd = (p == string::npos)
            ? line
            : line.substr(0, p);

        currentArgs = (p == string::npos)
            ? ""
            : line.substr(p + 1);

        // Remove leading spaces
        while (
            !currentArgs.empty() &&
            currentArgs[0] == ' '
        ) {
            currentArgs.erase(currentArgs.begin());
        }

        // Check for consecutive delimiters
        if (currentArgs.find("||") != string::npos) {
            error(900);
            continue;
        }

        // Execute the command
        if (cmd == "LOAD") {
            LOAD();
        }
        else if (cmd == "ADD") {
            ADD();
        }
        else if (cmd == "QPOP") {
            QPOP();
        }
        else if (cmd == "SEARCH") {
            SEARCH();
        }
        else if (cmd == "MAKERT") {
            MAKERT();
        }
        else if (cmd == "PRINT") {
            PRINT();
        }
        else if (cmd == "DELETE") {
            DELETE();
        }
        else if (cmd == "EXIT") {
            EXIT();
            break;
        }
        else {
            error(1000);
        }
    }

    fcmd.close();
    flog.close();
}


// LOAD: Read the exercise list file
void Manager::LOAD() {
    // Check whether data already exists
    if (
        q.count() != 0 ||
        !exb.all().empty() ||
        !eqb.all().empty()
    ) {
        error(100);
        return;
    }

    ifstream f("Exercise_List.txt");

    if (!f) {
        error(100);
        return;
    }

    vector<SetData> v;
    string line;

    // Validate all data in the file
    while (getline(f, line)) {
        SetData d;

        if (!parseSet(line, d)) {
            error(100);
            return;
        }

        v.push_back(d);
    }

    // Check the number of data entries
    if (v.empty() || v.size() > 100) {
        error(100);
        return;
    }

    // Add data to the queue
    for (const auto& d : v) {
        q.add(d);
    }

    // Write the result to the log
    string b;

    for (const auto& d : v) {
        b += d.line() + "\n";
    }

    block("LOAD", b);
}


// QPOP: Transfer queue data to the BSTs
void Manager::QPOP() {
    if (q.empty()) {
        error(300);
        return;
    }

    // Transfer all queue data to both BSTs
    while (!q.empty()) {
        WorkoutQueueNode* node = q.pop();

        SetData d = node->data();

        exb.insert(d);
        eqb.insert(d);

        delete node;
    }

    block("QPOP", "Success");
}


// ADD: Add exercise data to the queue
void Manager::ADD() {
    SetData d;

    if (
        currentArgs.empty() ||
        !parseSet(currentArgs, d) ||
        q.full() ||
        q.contains(d)
    ) {
        error(200);
        return;
    }

    q.add(d);

    block("ADD", d.line());
}


// SEARCH: Search for data
void Manager::SEARCH() {
    istringstream is(currentArgs);

    string kind;
    is >> kind;

    string arg;
    getline(is, arg);

    if (!arg.empty() && arg[0] == ' ') {
        arg.erase(0, 1);
    }

    bool ok = false;

    vector<SetData> v = selectData(kind, arg, ok);

    if (!ok || v.empty()) {
        error(400);
        return;
    }

    string b;

    for (const auto& d : v) {
        b += d.line() + "\n";
    }

    block("SEARCH", b);
}


// MAKERT: Add data to the routine
void Manager::MAKERT() {
    istringstream is(currentArgs);

    string pos;
    string kind;

    is >> pos >> kind;

    string arg;
    getline(is, arg);

    if (!arg.empty() && arg[0] == ' ') {
        arg.erase(0, 1);
    }

    bool ok = false;

    vector<SetData> v = selectData(kind, arg, ok);

    // Check the position, search results, and routine capacity
    if (
        (pos != "FRONT" && pos != "BACK") ||
        !ok ||
        v.empty() ||
        rt.size() + static_cast<int>(v.size()) > 10
    ) {
        error(500);
        return;
    }

    // Check for data that already exists in the routine
    for (const auto& d : v) {
        if (rt.contains(d)) {
            error(500);
            return;
        }
    }

    // Add data at the specified position
    if (pos == "FRONT") {
        for (auto i = v.rbegin(); i != v.rend(); ++i) {
            rt.addFront(*i);
        }
    }
    else {
        for (const auto& d : v) {
            rt.addBack(d);
        }
    }

    block("MAKERT", rt.print());
}


// PRINT: Display the contents of a data structure
void Manager::PRINT() {
    if (currentArgs == "EXERCISE") {
        auto v = exb.all();

        if (v.empty()) {
            error(600);
            return;
        }

        string b = "ExerciseBST\n";

        for (const auto& d : v) {
            b += d.line() + "\n";
        }

        block("PRINT", b);
    }
    else if (currentArgs == "EQUIPMENT") {
        auto v = eqb.all();

        if (v.empty()) {
            error(600);
            return;
        }

        string b = "EquipmentBST\n";

        for (const auto& d : v) {
            b += d.line() + "\n";
        }

        block("PRINT", b);
    }
    else if (currentArgs == "ROUTINE") {
        if (rt.empty()) {
            error(600);
        }
        else {
            block("PRINT", rt.print());
        }
    }
    else {
        error(600);
    }
}


// DELETE: Remove data from a data structure
void Manager::DELETE() {
    istringstream is(currentArgs);

    string kind;
    is >> kind;

    string arg;
    getline(is, arg);

    if (!arg.empty() && arg[0] == ' ') {
        arg.erase(0, 1);
    }

    bool success = false;

    // Remove the first item from the routine
    if (kind == "FRONT") {
        success = rt.pop_front();
    }
    // Remove the last item from the routine
    else if (kind == "BACK") {
        success = rt.pop_back();
    }
    // Remove a specific exercise-equipment pair from the routine
    else if (kind == "ROUTINE") {
        size_t z = arg.find('|');

        if (z != string::npos) {
            SetData d;

            d.exercise = arg.substr(0, z);
            d.equipment = arg.substr(z + 1);

            success = rt.remove(d);
        }
    }
    // Remove a specific exercise-equipment pair from both BSTs
    else if (kind == "SET") {
        size_t z = arg.find('|');

        if (z != string::npos) {
            SetData d;

            d.exercise = arg.substr(0, z);
            d.equipment = arg.substr(z + 1);

            success = exb.eraseSet(d);
            eqb.eraseSet(d);
            rt.remove(d);
        }
    }
    // Remove all data for a specific exercise
    else if (kind == "EXERCISE") {
        auto v = exb.eraseExercise(arg);

        for (const auto& d : v) {
            eqb.eraseSet(d);
            rt.remove(d);
        }

        success = !v.empty();
    }
    // Remove all data for a specific equipment
    else if (kind == "EQUIPMENT") {
        auto v = eqb.eraseEquipment(arg);

        for (const auto& d : v) {
            exb.eraseSet(d);
            rt.remove(d);
        }

        success = !v.empty();
    }

    if (success) {
        block("DELETE", "Success");
    }
    else {
        error(700);
    }
}


// EXIT: Handle program termination
void Manager::EXIT() {
    block("EXIT", "Success");
}