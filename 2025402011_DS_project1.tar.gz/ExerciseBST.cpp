#include "ExerciseBST.h"

// Constructor and destructor
ExerciseBST::ExerciseBST()
    : root(nullptr) {}

ExerciseBST::~ExerciseBST() {
    clear(root);
}

// Release memory for all nodes
void ExerciseBST::clear(ExerciseBSTNode* n) {
    if (!n) return;

    clear(n->left);
    clear(n->right);

    delete n;
}

// Existing interface
void ExerciseBST::insert() {}

void ExerciseBST::search() {}

void ExerciseBST::print() {}

// Insert data using the exercise name as the key
void ExerciseBST::insert(const SetData& d) {
    ExerciseBSTNode** p = &root;

    while (*p) {
        if (d.exercise < (*p)->exercise) {
            p = &(*p)->left;
        }
        else if (d.exercise > (*p)->exercise) {
            p = &(*p)->right;
        }
        else {
            // Check for duplicate equipment in the same exercise node
            for (const auto& s : (*p)->sets) {
                if (s.equipment == d.equipment) {
                    return;
                }
            }

            ExerciseSet item;
            item.equipment = d.equipment;
            item.duration = d.dtime;
            item.calories = d.kcal;
            item.seconds = d.seconds;

            (*p)->sets.push_back(item);
            ++(*p)->count;

            return;
        }
    }

    // Create a new exercise node
    *p = new ExerciseBSTNode();
    (*p)->exercise = d.exercise;

    ExerciseSet item;
    item.equipment = d.equipment;
    item.duration = d.dtime;
    item.calories = d.kcal;
    item.seconds = d.seconds;

    (*p)->sets.push_back(item);
    (*p)->count = 1;
}

// Collect all data using inorder traversal
void ExerciseBST::inorder(
    ExerciseBSTNode* n,
    std::vector<SetData>& v
) const {
    if (!n) return;

    inorder(n->left, v);

    for (const auto& s : n->sets) {
        SetData d;

        d.exercise = n->exercise;
        d.equipment = s.equipment;
        d.dtime = s.duration;
        d.kcal = s.calories;
        d.seconds = s.seconds;

        v.push_back(d);
    }

    inorder(n->right, v);
}

// Return all data
std::vector<SetData> ExerciseBST::all() const {
    std::vector<SetData> v;

    inorder(root, v);

    return v;
}

// Return data for a specific exercise
std::vector<SetData> ExerciseBST::byExercise(
    const std::string& e
) const {
    std::vector<SetData> v;

    for (const auto& d : all()) {
        if (d.exercise == e) {
            v.push_back(d);
        }
    }

    return v;
}

// Check whether an exercise exists
bool ExerciseBST::containsExercise(
    const std::string& e
) const {
    return !byExercise(e).empty();
}

// Check whether a specific exercise-equipment pair exists
bool ExerciseBST::contains(const SetData& d) const {
    for (const auto& x : byExercise(d.exercise)) {
        if (x.equipment == d.equipment) {
            return true;
        }
    }

    return false;
}

// Remove a specific exercise entry
ExerciseBSTNode* ExerciseBST::removeSet(
    ExerciseBSTNode* n,
    const SetData& d,
    bool& removed
) {
    if (!n) return n;

    if (d.exercise < n->exercise) {
        n->left = removeSet(n->left, d, removed);
    }
    else if (d.exercise > n->exercise) {
        n->right = removeSet(n->right, d, removed);
    }
    else {
        // Find the matching equipment entry
        for (auto i = n->sets.begin();
             i != n->sets.end(); ++i) {

            if (i->equipment == d.equipment) {
                n->sets.erase(i);
                removed = true;
                break;
            }
        }

        n->count = static_cast<int>(n->sets.size());

        // Remove the exercise node if no entries remain
        if (n->sets.empty()) {
            if (!n->left) {
                auto r = n->right;
                delete n;
                return r;
            }

            if (!n->right) {
                auto l = n->left;
                delete n;
                return l;
            }

            // Use the inorder successor when the node has two children
            auto succ = n->right;

            while (succ->left) {
                succ = succ->left;
            }

            n->exercise = succ->exercise;
            n->sets = succ->sets;
            n->count = succ->count;

            n->right = removeWholeNode(
                n->right,
                succ->exercise
            );
        }
    }

    return n;
}

// Remove an entire exercise node
ExerciseBSTNode* ExerciseBST::removeWholeNode(
    ExerciseBSTNode* n,
    const std::string& key
) {
    if (!n) return nullptr;

    if (key < n->exercise) {
        n->left = removeWholeNode(n->left, key);
    }
    else if (key > n->exercise) {
        n->right = removeWholeNode(n->right, key);
    }
    else {
        if (!n->left) {
            auto r = n->right;
            delete n;
            return r;
        }

        if (!n->right) {
            auto l = n->left;
            delete n;
            return l;
        }

        // Use the inorder successor when the node has two children
        auto succ = n->right;

        while (succ->left) {
            succ = succ->left;
        }

        n->exercise = succ->exercise;
        n->sets = succ->sets;
        n->count = succ->count;

        n->right = removeWholeNode(
            n->right,
            succ->exercise
        );
    }

    return n;
}

// Execute deletion of a specific exercise entry
bool ExerciseBST::eraseSet(const SetData& d) {
    bool removed = false;

    root = removeSet(root, d, removed);

    return removed;
}

// Remove all entries for a specific exercise
std::vector<SetData> ExerciseBST::eraseExercise(
    const std::string& e
) {
    auto old = byExercise(e);

    for (const auto& d : old) {
        eraseSet(d);
    }

    return old;
}

// Existing interface
void ExerciseBST::delete_node() {}
