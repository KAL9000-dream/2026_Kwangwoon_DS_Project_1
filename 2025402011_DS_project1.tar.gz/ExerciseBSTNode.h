#include "SetData.h"
#include <string>
#include <vector>

// Equipment data grouped by exercise
struct ExerciseSet {
    std::string equipment;
    std::string duration;

    int calories = 0;
    int seconds = 0;
};

class ExerciseBSTNode {
    friend class ExerciseBST;

private:
    std::string exercise;
    std::vector<ExerciseSet> sets;
    int count = 0;

    ExerciseBSTNode* left = nullptr;
    ExerciseBSTNode* right = nullptr;

public:
    // Constructor and Destructor
    ExerciseBSTNode() = default;
    ~ExerciseBSTNode() = default;

    // Existing interface
    void set() {}
    void search() {}
};