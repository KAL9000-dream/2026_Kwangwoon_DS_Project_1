#include "EquipmentBSTNode.h"

class EquipmentBST {
private:
    EquipmentBSTNode* root;

    // Memory management
    void clear(EquipmentBSTNode* n);

    // Node deletion
    EquipmentBSTNode* removeWholeNode(
        EquipmentBSTNode* n,
        const std::string& key
    );

    EquipmentBSTNode* removeSet(
        EquipmentBSTNode* n,
        const SetData& d,
        bool& removed
    );

    // In-order traversal
    void inorder(
        EquipmentBSTNode* n,
        std::vector<SetData>& v
    ) const;

public:
    // Constructor and Destructor
    EquipmentBST();
    ~EquipmentBST();

    // Existing interface
    void insert();
    void search();
    void print();
    void delete_node();

    // Data insertion and search
    void insert(const SetData& d);

    bool contains(const SetData& d) const;
    bool containsEquipment(const std::string& e) const;

    std::vector<SetData> all() const;

    std::vector<SetData> byEquipment(
        const std::string& e
    ) const;

    // Data deletion
    bool eraseSet(const SetData& d);

    std::vector<SetData> eraseEquipment(
        const std::string& e
    );
};