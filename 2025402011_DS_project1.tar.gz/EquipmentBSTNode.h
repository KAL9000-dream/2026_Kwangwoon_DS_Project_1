#include "SetData.h"
#include <string>
#include <vector>

// Exercise data grouped by equipment
struct EquipmentSet {
    std::string exercise;
    std::string duration;
    int calories = 0;
    int seconds = 0;
};

class EquipmentBSTNode {
    friend class EquipmentBST;

private:
    std::string equipment;
    std::vector<EquipmentSet> sets;
    int count = 0;

    EquipmentBSTNode* left = nullptr;
    EquipmentBSTNode* right = nullptr;

public:
    EquipmentBSTNode() = default;
    ~EquipmentBSTNode() = default;

    // Existing interface
    void set() {}
    void search() {}
};