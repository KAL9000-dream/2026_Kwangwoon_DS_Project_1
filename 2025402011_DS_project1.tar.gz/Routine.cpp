#include "Routine.h"

// Constructor and Destructor
Routine::Routine()
    : head(nullptr),
      tail(nullptr),
      count(0),
      total_sec(0),
      total_kcal(0),
      capacity(10) {}

Routine::~Routine() {
    while (!empty()) {
        pop_front();
    }
}


// Status and info check
bool Routine::empty() {
    return count == 0;
}

bool Routine::full() {
    return count >= capacity;
}

bool Routine::exist() {
    return !empty();
}

int Routine::duration() {
    return total_sec;
}

int Routine::calories() {
    return total_kcal;
}


// Existing interface
void Routine::push_front() {}

void Routine::push_back() {}

void Routine::delete_node() {}


// Check if specific data already exists in the routine
bool Routine::contains(const SetData& d) const {
    for (auto n = head; n; n = n->next) {
        if (
            n->exercise == d.exercise &&
            n->equipment == d.equipment
        ) {
            return true;
        }
    }

    return false;
}


// Add data to the front of the routine
bool Routine::addFront(const SetData& d) {
    if (full() || contains(d)) {
        return false;
    }

    auto n = new RoutineNode(d);

    n->next = head;

    if (head) {
        head->prev = n;
    }
    else {
        tail = n;
    }

    head = n;

    ++count;
    total_sec += d.seconds;
    total_kcal += d.kcal;

    return true;
}


// Add data to the back of the routine
bool Routine::addBack(const SetData& d) {
    if (full() || contains(d)) {
        return false;
    }

    auto n = new RoutineNode(d);

    n->prev = tail;

    if (tail) {
        tail->next = n;
    }
    else {
        head = n;
    }

    tail = n;

    ++count;
    total_sec += d.seconds;
    total_kcal += d.kcal;

    return true;
}


// Unlink and delete node
void Routine::unlink(RoutineNode* n) {
    if (!n) {
        return;
    }

    if (n->prev) {
        n->prev->next = n->next;
    }
    else {
        head = n->next;
    }

    if (n->next) {
        n->next->prev = n->prev;
    }
    else {
        tail = n->prev;
    }

    total_sec -= n->seconds;
    total_kcal -= n->kcal;
    --count;

    delete n;
}


// Remove the front data of the routine
bool Routine::pop_front() {
    if (empty()) {
        return false;
    }

    unlink(head);

    return true;
}


// Remove the back data of the routine
bool Routine::pop_back() {
    if (empty()) {
        return false;
    }

    unlink(tail);

    return true;
}


// Remove specified exercise and equipment data
bool Routine::remove(const SetData& d) {
    for (auto n = head; n; n = n->next) {
        if (
            n->exercise == d.exercise &&
            n->equipment == d.equipment
        ) {
            unlink(n);
            return true;
        }
    }

    return false;
}


// Return all data in the routine
std::vector<SetData> Routine::all() const {
    std::vector<SetData> v;

    for (auto n = head; n; n = n->next) {
        SetData d;

        d.exercise = n->exercise;
        d.equipment = n->equipment;
        d.dtime = n->dtime;
        d.kcal = n->kcal;
        d.seconds = n->seconds;

        v.push_back(d);
    }

    return v;
}


// Generate string output for the routine
std::string Routine::print() {
    std::string s;

    for (const auto& d : all()) {
        s += d.line() + "\n";
    }

    s += "Count: " + std::to_string(count) + " / 10\n";
    s += "Time: " + timeString(total_sec) + "\n";
    s += "Kcal: " + std::to_string(total_kcal) + "\n";

    return s;
}