#include "EquipmentBST.h"

#include <algorithm>
#include <utility>

using namespace std;


// Constructor
EquipmentBST::EquipmentBST() : root(nullptr) {}


// Destructor
EquipmentBST::~EquipmentBST() {
    clear(root);
    root = nullptr;
}


// Delete every node in the tree
void EquipmentBST::clear(EquipmentBSTNode* n) {
    if (n == nullptr) {
        return;
    }

    clear(n->left);
    clear(n->right);

    delete n;
}


// Insert a set into the equipment BST
void EquipmentBST::insert(const SetData& d) {
    EquipmentBSTNode** current = &root;

    while (*current != nullptr) {
        if (d.equipment < (*current)->equipment) {
            current = &((*current)->left);
        }
        else if (d.equipment > (*current)->equipment) {
            current = &((*current)->right);
        }
        else {
            // The equipment node already exists.
            for (const auto& s : (*current)->sets) {
                if (s.exercise == d.exercise) {
                    return;
                }
            }

            EquipmentSet s;
            s.exercise = d.exercise;
            s.duration = d.dtime;
            s.calories = d.kcal;
            s.seconds = d.seconds;

            (*current)->sets.push_back(s);
            (*current)->count =
                static_cast<int>((*current)->sets.size());

            return;
        }
    }

    // Create a new equipment node.
    *current = new EquipmentBSTNode();
    (*current)->equipment = d.equipment;

    EquipmentSet s;
    s.exercise = d.exercise;
    s.duration = d.dtime;
    s.calories = d.kcal;
    s.seconds = d.seconds;

    (*current)->sets.push_back(s);
    (*current)->count = 1;
}


// Check whether an exercise-equipment pair exists
bool EquipmentBST::contains(const SetData& d) const {
    EquipmentBSTNode* current = root;

    while (current != nullptr) {
        if (d.equipment < current->equipment) {
            current = current->left;
        }
        else if (d.equipment > current->equipment) {
            current = current->right;
        }
        else {
            for (const auto& s : current->sets) {
                if (s.exercise == d.exercise) {
                    return true;
                }
            }

            return false;
        }
    }

    return false;
}


// Check whether an equipment node exists
bool EquipmentBST::containsEquipment(
    const string& e
) const {
    EquipmentBSTNode* current = root;

    while (current != nullptr) {
        if (e < current->equipment) {
            current = current->left;
        }
        else if (e > current->equipment) {
            current = current->right;
        }
        else {
            return true;
        }
    }

    return false;
}


// Traverse the tree in ascending equipment order
void EquipmentBST::inorder(
    EquipmentBSTNode* n,
    vector<SetData>& v
) const {
    if (n == nullptr) {
        return;
    }

    inorder(n->left, v);

    for (const auto& s : n->sets) {
        SetData d;
        d.exercise = s.exercise;
        d.equipment = n->equipment;
        d.dtime = s.duration;
        d.kcal = s.calories;
        d.seconds = s.seconds;

        v.push_back(d);
    }

    inorder(n->right, v);
}


// Return all sets
vector<SetData> EquipmentBST::all() const {
    vector<SetData> v;
    inorder(root, v);
    return v;
}


// Return sets associated with a particular equipment
vector<SetData> EquipmentBST::byEquipment(
    const string& e
) const {
    vector<SetData> v;
    EquipmentBSTNode* current = root;

    while (current != nullptr) {
        if (e < current->equipment) {
            current = current->left;
        }
        else if (e > current->equipment) {
            current = current->right;
        }
        else {
            for (const auto& s : current->sets) {
                SetData d;
                d.exercise = s.exercise;
                d.equipment = current->equipment;
                d.dtime = s.duration;
                d.kcal = s.calories;
                d.seconds = s.seconds;

                v.push_back(d);
            }

            return v;
        }
    }

    return v;
}


// Remove an entire equipment node
EquipmentBSTNode* EquipmentBST::removeWholeNode(
    EquipmentBSTNode* n,
    const string& key
) {
    if (n == nullptr) {
        return nullptr;
    }

    if (key < n->equipment) {
        n->left = removeWholeNode(n->left, key);
        return n;
    }

    if (key > n->equipment) {
        n->right = removeWholeNode(n->right, key);
        return n;
    }

    // The node has no left child.
    if (n->left == nullptr) {
        EquipmentBSTNode* replacement = n->right;
        delete n;
        return replacement;
    }

    // The node has no right child.
    if (n->right == nullptr) {
        EquipmentBSTNode* replacement = n->left;
        delete n;
        return replacement;
    }

    // The node has two children.
    // Replace it with the smallest node in its right subtree.
    EquipmentBSTNode* successor = n->right;

    while (successor->left != nullptr) {
        successor = successor->left;
    }

    n->equipment = successor->equipment;
    n->sets = successor->sets;
    n->count = successor->count;

    n->right = removeWholeNode(
        n->right,
        successor->equipment
    );

    return n;
}


// Remove one exercise-equipment pair
EquipmentBSTNode* EquipmentBST::removeSet(
    EquipmentBSTNode* n,
    const SetData& d,
    bool& removed
) {
    if (n == nullptr) {
        return nullptr;
    }

    if (d.equipment < n->equipment) {
        n->left = removeSet(n->left, d, removed);
        return n;
    }

    if (d.equipment > n->equipment) {
        n->right = removeSet(n->right, d, removed);
        return n;
    }

    // Find the exercise in this equipment node.
    for (auto it = n->sets.begin(); it != n->sets.end(); ++it) {
        if (it->exercise == d.exercise) {
            n->sets.erase(it);
            n->count = static_cast<int>(n->sets.size());
            removed = true;
            break;
        }
    }

    // Remove the equipment node if it has no sets left.
    if (n->sets.empty()) {
        return removeWholeNode(n, n->equipment);
    }

    return n;
}


// Public deletion function for a single set
bool EquipmentBST::eraseSet(const SetData& d) {
    bool removed = false;
    root = removeSet(root, d, removed);
    return removed;
}


// Remove all sets for a given equipment
vector<SetData> EquipmentBST::eraseEquipment(
    const string& e
) {
    vector<SetData> removed;

    // Find the equipment node.
    EquipmentBSTNode* current = root;

    while (current != nullptr) {
        if (e < current->equipment) {
            current = current->left;
        }
        else if (e > current->equipment) {
            current = current->right;
        }
        else {
            // Save the data before deleting the node.
            for (const auto& s : current->sets) {
                SetData d;
                d.exercise = s.exercise;
                d.equipment = current->equipment;
                d.dtime = s.duration;
                d.kcal = s.calories;
                d.seconds = s.seconds;

                removed.push_back(d);
            }

            break;
        }
    }

    if (!removed.empty()) {
        root = removeWholeNode(root, e);
    }

    return removed;
}
