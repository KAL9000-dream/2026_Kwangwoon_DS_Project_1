#include "RoutineNode.h"

#include <string>
#include <vector>

class Routine {
private:
    RoutineNode* head;
    RoutineNode* tail;

    int count;
    int total_sec;
    int total_kcal;
    int capacity;

    void unlink(RoutineNode* n);

public:
    // Constructor and destructor
    Routine();
    ~Routine();

    // Existing interface
    void push_front();
    void push_back();
    void delete_node();

    // Check status and retrieve information
    bool empty();
    bool full();
    bool exist();

    int size() const {
        return count;
    }

    int duration();
    int calories();

    // Search and manage data
    bool contains(const SetData& d) const;
    bool addFront(const SetData& d);
    bool addBack(const SetData& d);
    bool remove(const SetData& d);

    bool pop_front();
    bool pop_back();

    // Retrieve and print data
    std::vector<SetData> all() const;
    std::string print();
};