#include "SetData.h"

#include <string>

class WorkoutQueue;

class WorkoutQueueNode {
    friend class WorkoutQueue;

private:
    // Exercise data
    std::string exercise;
    std::string equipment;
    std::string dtime;
    int kcal = 0;

    // Linked list pointers
    WorkoutQueueNode* next = nullptr;
    WorkoutQueueNode* prev = nullptr;

public:
    // Default constructor
    WorkoutQueueNode() = default;

    // Construct a node from exercise data
    explicit WorkoutQueueNode(const SetData& d)
        : exercise(d.exercise),
          equipment(d.equipment),
          dtime(d.dtime),
          kcal(d.kcal) {}

    // Return node data as a SetData object
    SetData data() const {
        SetData d;

        d.exercise = exercise;
        d.equipment = equipment;
        d.dtime = dtime;
        d.kcal = kcal;

        parseSet(
            d.exercise + "|" +
            d.equipment + "|" +
            d.dtime + "|" +
            std::to_string(d.kcal),
            d
        );

        return d;
    }

    // Existing interface
    void set() {}

    bool exist() {
        return false;
    }
};