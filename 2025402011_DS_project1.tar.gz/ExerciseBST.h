#include "ExerciseBSTNode.h"

class ExerciseBST {
private:
    ExerciseBSTNode* root;

    // Memory management
    void clear(ExerciseBSTNode* n);

    // Node deletion
    ExerciseBSTNode* removeWholeNode(
        ExerciseBSTNode* n,
        const std::string& key
    );

    ExerciseBSTNode* removeSet(
        ExerciseBSTNode* n,
        const SetData& d,
        bool& removed
    );

    // In-order traversal
    void inorder(
        ExerciseBSTNode* n,
        std::vector<SetData>& v
    ) const;

public:
    // Constructor and Destructor
    ExerciseBST();
    ~ExerciseBST();

    // Existing interface
    void insert();
    void search();
    void print();
    void delete_node();

    // Data insertion and search
    void insert(const SetData& d);

    bool contains(const SetData& d) const;
    bool containsExercise(const std::string& e) const;

    std::vector<SetData> all() const;

    std::vector<SetData> byExercise(
        const std::string& e
    ) const;

    // Data deletion
    bool eraseSet(const SetData& d);

    std::vector<SetData> eraseExercise(
        const std::string& e
    );
};