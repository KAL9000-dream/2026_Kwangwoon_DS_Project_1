#include "WorkoutQueue.h"
#include "ExerciseBST.h"
#include "EquipmentBST.h"
#include "Routine.h"

#include <fstream>
#include <string>
#include <vector>

class Manager {
private:
    // Data structure objects
    WorkoutQueue q;
    ExerciseBST exb;
    EquipmentBST eqb;
    Routine rt;

    // Command file and log file streams
    std::ifstream fcmd;
    std::ofstream flog;

    // Arguments of the current command
    std::string currentArgs;

    // Logging and error handling
    void error(int code);

    void block(
        const std::string& header,
        const std::string& body
    );

    // Select data matching the search condition
    std::vector<SetData> selectData(
        const std::string& kind,
        const std::string& arg,
        bool& ok
    ) const;

public:
    // Constructor and Destructor
    Manager();
    ~Manager();

    // Command execution
    void run(const char* command);

    // Command processing functions
    void LOAD();
    void ADD();
    void QPOP();
    void SEARCH();
    void MAKERT();
    void PRINT();
    void DELETE();
    void EXIT();
};