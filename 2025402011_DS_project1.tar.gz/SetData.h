#ifndef SETDATA_H
#define SETDATA_H
#include <string>
#include <sstream>
#include <iomanip>

// Exercise data
struct SetData {
    std::string exercise;
    std::string equipment;
    std::string dtime;

    int kcal = 0;
    int seconds = 0;

    // Convert data to a string
    std::string line() const {
        return exercise + "/" +
               equipment + "/" +
               dtime + "/" +
               std::to_string(kcal);
    }
};

// Convert a string to SetData
inline bool parseSet(
    const std::string& s,
    SetData& d,
    char delimiter = '|'
) {
    size_t a = s.find(delimiter);

    size_t b = (a == std::string::npos)
        ? a
        : s.find(delimiter, a + 1);

    size_t c = (b == std::string::npos)
        ? b
        : s.find(delimiter, b + 1);

    // Check the number of delimiters
    if (
        a == std::string::npos ||
        b == std::string::npos ||
        c == std::string::npos ||
        s.find(delimiter, c + 1) != std::string::npos
    ) {
        return false;
    }

    // Split the input data
    d.exercise = s.substr(0, a);
    d.equipment = s.substr(a + 1, b - a - 1);
    d.dtime = s.substr(b + 1, c - b - 1);

    std::string k = s.substr(c + 1);

    // Check for empty fields
    if (
        d.exercise.empty() ||
        d.equipment.empty() ||
        d.dtime.empty() ||
        k.empty()
    ) {
        return false;
    }

    // Convert calories to an integer
    try {
        d.kcal = std::stoi(k);
    }
    catch (...) {
        return false;
    }

    // Validate the exercise time format
    size_t colon = d.dtime.find(':');

    if (colon == std::string::npos) {
        return false;
    }

    // Convert minutes and seconds to total seconds
    try {
        int m = std::stoi(d.dtime.substr(0, colon));
        int sec = std::stoi(d.dtime.substr(colon + 1));

        if (m < 0 || sec < 0 || sec >= 60) {
            return false;
        }

        d.seconds = m * 60 + sec;
    }
    catch (...) {
        return false;
    }

    return true;
}

// Check whether two entries have the same exercise and equipment
inline bool sameSet(
    const SetData& a,
    const SetData& b
) {
    return a.exercise == b.exercise &&
           a.equipment == b.equipment;
}

// Convert seconds to a formatted time string
inline std::string timeString(int sec) {
    std::ostringstream o;

    o << sec / 60 << "min "
      << sec % 60 << "sec";

    return o.str();
}
#endif // SETDATA_H
