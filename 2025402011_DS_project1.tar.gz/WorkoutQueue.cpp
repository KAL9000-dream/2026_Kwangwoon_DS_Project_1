#include "WorkoutQueue.h"

// Constructor and destructor
WorkoutQueue::WorkoutQueue()
    : head(nullptr),
      rear(nullptr),
      size(0),
      capacity(100) {}

WorkoutQueue::~WorkoutQueue() {
    while (!empty()) {
        delete pop();
    }
}


// Check queue status
bool WorkoutQueue::empty() {
    return size == 0;
}

bool WorkoutQueue::full() {
    return size >= capacity;
}

bool WorkoutQueue::exist() {
    return !empty();
}


// Check for duplicate data
bool WorkoutQueue::contains(const SetData& d) const {
    for (auto n = head; n; n = n->next) {
        if (
            n->exercise == d.exercise &&
            n->equipment == d.equipment
        ) {
            return true;
        }
    }

    return false;
}


// Add data to the rear of the queue
bool WorkoutQueue::add(const SetData& d) {
    if (full() || contains(d)) {
        return false;
    }

    auto n = new WorkoutQueueNode(d);

    n->prev = rear;

    if (rear) {
        rear->next = n;
    }
    else {
        head = n;
    }

    rear = n;
    ++size;

    return true;
}


// Existing interface
void WorkoutQueue::push() {}


// Remove and return the front node
WorkoutQueueNode* WorkoutQueue::pop() {
    if (empty()) {
        return nullptr;
    }

    auto n = head;

    head = head->next;

    if (head) {
        head->prev = nullptr;
    }
    else {
        rear = nullptr;
    }

    n->next = nullptr;
    n->prev = nullptr;

    --size;

    return n;
}


// Return the front node
WorkoutQueueNode* WorkoutQueue::front() {
    return head;
}
